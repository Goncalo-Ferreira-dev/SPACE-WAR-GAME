import random

class Tabuleiro:
    def __init__(self, linhas=5, colunas=5):
        self.linhas = linhas
        self.colunas = colunas
        self.max = linhas * colunas
        self.grid = [["." for _ in range(colunas)] for _ in range(linhas)]

    def limpar(self):
        self.grid = [["." for _ in range(self.colunas)] for _ in range(self.linhas)]

    def colocar(self, pos, simbolo):
        l = pos // self.colunas
        c = pos % self.colunas
        self.grid[l][c] = simbolo

    def desenhar(self):
        print("  " + " ".join(str(i) for i in range(self.colunas)))

        for i, linha in enumerate(self.grid):
            print(f"{i} " + " ".join(linha))

    def posicao_livre(self, usadas):
        pos = random.randint(0, self.max - 1)
        
        while pos in usadas:
            pos = random.randint(0, self.max - 1)
        return pos

    def lc_para_pos(self, linha, coluna):
        return linha * self.colunas + coluna
