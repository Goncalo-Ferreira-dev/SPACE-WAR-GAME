import os
import json

SAVE_FOLDER = "saves"

def limpar():
    os.system("cls" if os.name == "nt" else "clear")

def tabuleiro():
    limpar()
    print("/-----------------------------\\")
    print("|       -MADE IN SPACE-       |")
    print("\-----------------------------/")

def menu():
    print("\n1 - Jogo Novo")
    print("2 - Carregar Jogo")
    print("3 - Apagar Saves")
    print("4 - Sair")
    return input("\nOpção: ")

def esperar():
    input("\nPressione ENTER para Continuar.")

def garantir_pasta():
    if not os.path.exists(SAVE_FOLDER):
        os.makedirs(SAVE_FOLDER)

def guardar_jogo(dados, nome_save):
    garantir_pasta()
    caminho = os.path.join(SAVE_FOLDER, f"{nome_save}.json")
    
    with open(caminho, "w") as f:
        json.dump(dados, f)
    print("\nJogo Salvo com Sucesso!")
    esperar()

def listar_saves():
    garantir_pasta()
    ficheiros = [f for f in os.listdir(SAVE_FOLDER) if f.endswith(".json")]
    return ficheiros

def carregar_jogo(nome_save):
    caminho = os.path.join(SAVE_FOLDER, nome_save)

    if not os.path.exists(caminho):
        print("Save não Encontrado.")
        esperar()
        return None
    with open(caminho, "r") as f:
        return json.load(f)

def apagar_save(nome_save):
    caminho = os.path.join(SAVE_FOLDER, nome_save)
    if os.path.exists(caminho):
        os.remove(caminho)

def apagar_todos_os_saves():
    garantir_pasta()

    for f in os.listdir(SAVE_FOLDER):
        if f.endswith(".json"):
            os.remove(os.path.join(SAVE_FOLDER, f))
