class NaveModelo:
    def __init__(self, nome, cor, simbolo, perda_energia):
        self.nome = nome
        self.cor = cor
        self.simbolo = simbolo
        self.perda_energia = perda_energia
        self.energia = 100

    def perder_energia(self):
        self.energia -= self.perda_energia

        if self.energia < 0:
            self.energia = 0

    def energia_atual(self):
        return self.energia


class NaveEspecial(NaveModelo):
    def __init__(self, nome, cor, simbolo, perda_energia, energia_extra):
        super().__init__(nome, cor, simbolo, perda_energia)
        self.energia_extra = energia_extra

    def mostrar_dados(self):
        print(f"{self.cor}{self.nome} -> Energia {self.energia}, Símbolo {self.simbolo}\033[0m")

    def adicionar_energia_extra(self):
        self.energia += self.energia_extra
        
        if self.energia > 100:
            self.energia = 100
