from naves import NaveEspecial
from tabuleiro import Tabuleiro

from funcoes import (
    tabuleiro, menu, esperar, limpar,
    guardar_jogo, carregar_jogo,
    listar_saves, apagar_save, apagar_todos_os_saves
)

import os

def pedir_tiro(tab, usados):
    while True:
        try:
            print("\nPosição do Tiro:")
            linha = int(input("Linha (0-4): "))
            coluna = int(input("Coluna (0-4): "))

            if not (0 <= linha <= 4):
                print("Linha Inválida.")
                continue

            if not (0 <= coluna <= 4):
                print("Coluna Inválida.")
                continue

            pos = tab.lc_para_pos(linha, coluna)

            if pos in usados:
                print("Já Disparou para este Lugar nesta Rodada.")
                continue

            return pos

        except ValueError:
            print("Valor inválido.")

def criar_naves():
    return [
        NaveEspecial("Dark Blue Sun", "\033[94m", "D", 20, 15),
        NaveEspecial("Meteor of Fortune", "\033[91m", "S", 15, 20),
        NaveEspecial("Tower of Space", "\033[90m", "T", 10, 10)
    ]

def iniciar_jogo(carregado=False, save=None, nome_save_atual=None):
    tab_naves = Tabuleiro()
    tab_tiros = Tabuleiro()

    if not carregado:
        naves = criar_naves()
        posicoes = {}
        usadas = []

        for nave in naves:
            p = tab_naves.posicao_livre(usadas)
            usadas.append(p)
            posicoes[nave.nome] = p
        total_tiros = 0
        acertos = 0
    else:
        print("\nCarregando...")
        naves = criar_naves()

        for nave in naves:
            nave.energia = save["naves"][nave.nome]

        posicoes = save["posicoes"]
        total_tiros = save["total_tiros"]
        acertos = save["acertos"]

    save_ja_tem_nome = nome_save_atual is not None

    while total_tiros < 105 and any(n.energia > 0 for n in naves):
        limpar()
        print("-----{ NOVA RODADA DE TIROS }-----\n")

        tiros = []

        for i in range(3):
            print(f"\nTiro {i+1}/3")
            pos = pedir_tiro(tab_naves, tiros)
            tiros.append(pos)

        for t in tiros:
            total_tiros += 1
            for nave in naves:
                if posicoes[nave.nome] == t and nave.energia > 0:
                    nave.perder_energia()
                    acertos += 1

        if total_tiros == 45:
            for n in naves:
                n.adicionar_energia_extra()

        for n in naves:
            if n.energia == 0:
                posicoes[n.nome] = None

        tab_naves.limpar()

        for n in naves:
            if n.energia > 0:
                tab_naves.colocar(posicoes[n.nome], n.simbolo)

        tab_tiros.limpar()

        for t in tiros:
            tab_tiros.colocar(t, "X")

        print("\nTabuleiro das Naves:")
        tab_naves.tabuleiro()

        print("\nTabuleiro dos Tiros:")
        tab_tiros.tabuleiro()

        print("\n---{ INFO DAS NAVES }---")

        for n in naves:
            n.mostrar_dados()

        media = (acertos * 100 / total_tiros)

        print(f"\nTiros dados: {total_tiros}")
        print(f"Tiros Acertados: {acertos}")
        print(f"Média de Acertos: {media:.2f}%")

        print("\n1 - Continuar")
        print("2 - Guardar Jogo e Voltar ao Menu")
        print("3 - Sair sem Guardar")

        op = input("> ")

        if op == "2":
            dados = {
                "total_tiros": total_tiros,
                "acertos": acertos,
                "posicoes": posicoes,
                "naves": {n.nome: n.energia for n in naves}
            }

            if save_ja_tem_nome:
                guardar_jogo(dados, nome_save_atual)
                return

            nome_save_atual = input("Nome do Save: ")
            save_ja_tem_nome = True
            guardar_jogo(dados, nome_save_atual)
            return

        elif op == "3":
            return

    print("\nFim do Jogo.")

    if all(n.energia == 0 for n in naves):
        print("Parabéns, Ganhaste.")

    esperar()

def menu_apagar_saves():
    while True:
        limpar()
        print("---{ APAGAR SAVES }---")
        print("1 - Apagar um Save")
        print("2 - Apagar TODOS os Saves")
        print("3 - Voltar")
        op = input("\nOpção: ")

        if op == "1":
            saves = listar_saves()

            if not saves:
                print("Não Foram Encontrados Saves.")
                esperar()
                continue

            print("\n---{ LISTA DE SAVES }---")

            for s in saves:
                print("- " + s)

            nome = input("\nEscreva o Nome do Save para Apagar: ")

            if not nome.endswith(".json"):
                nome += ".json"

            if nome not in saves:
                print("Save não Encontrado.")
                esperar()
                continue

            apagar_save(nome)
            print("Save Apagado com Sucesso.")
            esperar()

        elif op == "2":
            apagar_todos_os_saves()
            print("Todos os Saves Foram Apagados.")
            esperar()

        elif op == "3":
            return

        else:
            print("Opção não Encontrada!")
            esperar()

def main():
    while True:
        tabuleiro()
        op = menu()

        if op == "1":
            iniciar_jogo()

        elif op == "2":
            limpar()
            saves = listar_saves()

            if not saves:
                print("Nenhum Save Encontrado.")
                esperar()
                continue

            print("---{ LISTA DE SAVES }---")

            for i, s in enumerate(saves):
                print(f"{i+1} - {s}")

            escolha = input("\nEscolha o Número do Save: ")

            try:
                idx = int(escolha) - 1

                if idx < 0 or idx >= len(saves):
                    print("Opção não Encontrada.")
                    esperar()
                    continue
                
            except ValueError:
                print("Opção não Encontrada.")
                esperar()
                continue

            nome_save = saves[idx]
            save = carregar_jogo(nome_save)

            if save:
                iniciar_jogo(
                    carregado=True,
                    save=save,
                    nome_save_atual=nome_save.replace(".json", "")
                )

        elif op == "3":
            menu_apagar_saves()

        else:
            break

if __name__ == "__main__":
    main()
